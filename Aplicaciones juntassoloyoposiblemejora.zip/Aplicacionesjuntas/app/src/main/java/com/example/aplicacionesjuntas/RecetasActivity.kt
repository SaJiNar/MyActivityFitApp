package com.example.aplicacionesjuntas

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CustomAdapter : RecyclerView.Adapter<CustomAdapter.ViewHolder>() {


    private val titles = arrayOf(
        "Ensalada César",
        "Pizza con masa de brócoli",
        "Videos"
    )

    private val details = arrayOf(
        "Tiempo: 15 minutos",
        "Tiempo: 30 minutos",
        "Hola"
    )

    private val ingredients = arrayOf(
        "Lechuga\nPollo\nQueso parmesano\nCroutones\nAceite de oliva\nJugo de limón\nMostaza\nSalsa Worcestershire\nAjo picado\nSal y pimienta al gusto",
        "Masa de brócoli\nTomate\nQueso mozzarella\nAceitunas\nJamón\nCebolla\nSalsa de tomate\nSal y pimienta al gusto",
        ""
    )

    private val steps = arrayOf(
        "1. Lavar y picar la lechuga.\n2. Cortar el pollo en trozos pequeños y saltearlo en aceite de oliva hasta que esté dorado.\n3. Agregar los croutones y el queso parmesano a la lechuga.\n4. En un tazón pequeño, mezclar el aceite de oliva, el jugo de limón, la mostaza, la salsa Worcestershire y el ajo picado. Agregar sal y pimienta al gusto.\n5. Mezclar la ensalada con la salsa y servir.",
        "1. Precalentar el horno a 200°C.\n2. Triturar la masa de brócoli y mezclar con el huevo, el queso mozzarella rallado y la sal.\n3. Extender la mezcla sobre una bandeja para hornear y darle forma de pizza.\n4. Hornear durante 15 minutos.\n5. Agregar la salsa de tomate, el jamón, la cebolla, las aceitunas y el queso mozzarella rallado.\n6. Hornear durante otros 10-15 minutos hasta que la pizza esté dorada y crujiente.\n7. Servir caliente.",
        ""
    )

    private val images = intArrayOf(
        R.drawable.ejemplo,
        R.drawable.ejemplo,
        R.drawable.ejemplo
    )

    override fun onCreateViewHolder(viewGroup: ViewGroup, i: Int): ViewHolder {
        val v = LayoutInflater.from(viewGroup.context)
            .inflate(R.layout.cardviewejemplo, viewGroup, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(viewHolder: ViewHolder, i: Int) {
        viewHolder.itemTitle.text = titles[i]
        viewHolder.itemDetail.text = details[i]
        viewHolder.itemImage.setImageResource(images[i])
    }

    override fun getItemCount(): Int {
        return titles.size
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var itemImage: ImageView
        var itemTitle: TextView
        var itemDetail: TextView

        init {
            itemImage = itemView.findViewById(R.id.item_image)
            itemTitle = itemView.findViewById(R.id.item_title)
            itemDetail = itemView.findViewById(R.id.item_detail)
        }
    }

    class RecetasActivity : AppCompatActivity() {

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            this.supportActionBar?.hide()
            setContentView(R.layout.lasrecetas)

            val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
            val adapter = CustomAdapter()

            recyclerView.layoutManager = LinearLayoutManager(this)
            recyclerView.adapter = adapter


        }
    }
    /*
    val button = findViewById<Button>(R.id.item_button)
    button.setOnClickListener { onClickButton() }
}


private fun onClickButton() {
    val ingredientsView = findViewById<TextView>(R.id.item_ingredients)
    val stepsView = findViewById<TextView>(R.id.item_steps)
    val button = findViewById<Button>(R.id.item_button)

    if (ingredientsView.visibility == View.GONE) {
        ingredientsView.visibility = View.VISIBLE
        stepsView.visibility = View.VISIBLE
        button.text = getString(R.string.hide_ingredients_and_steps)
    } else {
        ingredientsView.visibility = View.GONE
        stepsView.visibility = View.GONE
        button.text = getString(R.string.show_ingredients_and_steps)
    }
}*/
}
